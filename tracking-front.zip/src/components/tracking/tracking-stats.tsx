import { useMemo } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
    Ship,
    MapPin,
    Clock,
    Route,
    Gauge,
    Navigation,
    Activity,
    Timer
} from "lucide-react"
import { format, differenceInMinutes } from "date-fns"
import { es } from "date-fns/locale"
import type { Tracking } from "@/types/tracking"
import type { Vessel } from "@/types/models/vessel"

interface TrackingStatsProps {
    trackings: Tracking[]
    vessel: Vessel | null
    isLoading?: boolean
}

export function TrackingStats({ trackings, vessel, isLoading = false }: TrackingStatsProps) {
    const stats = useMemo(() => {
        if (!trackings.length) {
            return {
                totalPoints: 0,
                totalDistance: 0,
                totalTime: 0,
                avgSpeed: 0,
                maxSpeed: 0,
                minSpeed: 0,
                timeMoving: 0,
                timeStopped: 0,
                firstPoint: null,
                lastPoint: null,
                coursesCount: 0,
                avgCourse: 0
            }
        }

        // Ordenar por fecha
        const sortedTrackings = [...trackings].sort((a, b) => {
            const dateA = new Date(a.reportedAt || a.tracked_at || a.created_at).getTime()
            const dateB = new Date(b.reportedAt || b.tracked_at || b.created_at).getTime()
            return dateA - dateB
        })

        const firstPoint = sortedTrackings[0]
        const lastPoint = sortedTrackings[sortedTrackings.length - 1]

        // Calcular distancia total usando la fórmula de Haversine
        let totalDistance = 0
        let totalTime = 0
        let timeMoving = 0
        let timeStopped = 0
        const speeds: number[] = []
        const courses: number[] = []

        for (let i = 1; i < sortedTrackings.length; i++) {
            const current = sortedTrackings[i]
            const previous = sortedTrackings[i - 1]

            // Calcular distancia entre puntos
            if (current.latitude && current.longitude && previous.latitude && previous.longitude) {
                const R = 6371 // Radio de la Tierra en km
                const dLat = (current.latitude - previous.latitude) * Math.PI / 180
                const dLon = (current.longitude - previous.longitude) * Math.PI / 180
                const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(previous.latitude * Math.PI / 180) *
                    Math.cos(current.latitude * Math.PI / 180) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2)
                const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
                const distance = R * c
                totalDistance += distance
            }

            // Calcular tiempo entre puntos
            const currentTime = new Date(current.reportedAt || current.tracked_at || current.created_at)
            const previousTime = new Date(previous.reportedAt || previous.tracked_at || previous.created_at)
            const timeDiff = differenceInMinutes(currentTime, previousTime)
            totalTime += timeDiff

            // Clasificar tiempo como en movimiento o parado
            const speed = current.speed || 0
            if (speed > 1) {
                timeMoving += timeDiff
            } else {
                timeStopped += timeDiff
            }

            // Recopilar velocidades y cursos
            if (current.speed !== undefined && current.speed !== null) {
                speeds.push(current.speed)
            }
            if (current.course !== undefined && current.course !== null) {
                courses.push(current.course)
            }
        }

        // Calcular estadísticas de velocidad
        const avgSpeed = speeds.length > 0 ? speeds.reduce((a, b) => a + b, 0) / speeds.length : 0
        const maxSpeed = speeds.length > 0 ? Math.max(...speeds) : 0
        const minSpeed = speeds.length > 0 ? Math.min(...speeds) : 0

        // Calcular curso promedio
        const avgCourse = courses.length > 0 ? courses.reduce((a, b) => a + b, 0) / courses.length : 0

        return {
            totalPoints: trackings.length,
            totalDistance,
            totalTime,
            avgSpeed,
            maxSpeed,
            minSpeed,
            timeMoving,
            timeStopped,
            firstPoint,
            lastPoint,
            coursesCount: courses.length,
            avgCourse
        }
    }, [trackings])

    const formatDuration = (minutes: number) => {
        const hours = Math.floor(minutes / 60)
        const mins = minutes % 60
        if (hours > 0) {
            return `${hours}h ${mins}m`
        }
        return `${mins}m`
    }

    const formatSpeed = (speed: number) => {
        return `${speed.toFixed(1)} kn`
    }

    const formatDistance = (distance: number) => {
        if (distance < 1) {
            return `${(distance * 1000).toFixed(0)} m`
        }
        return `${distance.toFixed(2)} km`
    }

    if (isLoading) {
        return (
            <div className="space-y-4">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Activity className="w-5 h-5" />
                            Estadísticas de Seguimiento
                        </CardTitle>
                        <CardDescription>Cargando estadísticas...</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                            {[...Array(6)].map((_, i) => (
                                <div key={i} className="space-y-2">
                                    <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                                    <div className="h-6 bg-gray-100 rounded animate-pulse"></div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        )
    }

    if (!trackings.length) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Activity className="w-5 h-5" />
                        Estadísticas de Seguimiento
                    </CardTitle>
                    <CardDescription>
                        No hay datos disponibles para mostrar estadísticas
                    </CardDescription>
                </CardHeader>
                <CardContent className="text-center py-8">
                    <Ship className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">
                        Selecciona una embarcación para ver las estadísticas
                    </p>
                </CardContent>
            </Card>
        )
    }

    return (
        <div className="space-y-4">
            {/* Información de la embarcación */}
            {vessel && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Ship className="w-5 h-5" />
                            {vessel.name || 'Embarcación'}
                        </CardTitle>                        <CardDescription>
                            {vessel.imo || 'Sin IMO'}
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="flex flex-wrap gap-2">
                            {vessel.vessel_type?.name && (
                                <Badge variant="outline">
                                    {vessel.vessel_type.name}
                                </Badge>
                            )}
                            {vessel.vessel_status?.name && (
                                <Badge
                                    variant={vessel.vessel_status.name === 'Activo' ? 'default' : 'secondary'}
                                >
                                    {vessel.vessel_status.name}
                                </Badge>
                            )}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Estadísticas principales */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Activity className="w-5 h-5" />
                        Resumen del Seguimiento
                    </CardTitle>
                    <CardDescription>
                        Período: {stats.firstPoint && format(new Date(stats.firstPoint.reportedAt || stats.firstPoint.tracked_at || stats.firstPoint.created_at), 'dd MMM yyyy', { locale: es })} - {stats.lastPoint && format(new Date(stats.lastPoint.reportedAt || stats.lastPoint.tracked_at || stats.lastPoint.created_at), 'dd MMM yyyy', { locale: es })}
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                                <MapPin className="w-4 h-4" />
                                <span>Puntos totales</span>
                            </div>
                            <div className="text-2xl font-bold">{stats.totalPoints}</div>
                        </div>

                        <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                                <Route className="w-4 h-4" />
                                <span>Distancia total</span>
                            </div>
                            <div className="text-2xl font-bold">{formatDistance(stats.totalDistance)}</div>
                        </div>

                        <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                                <Timer className="w-4 h-4" />
                                <span>Tiempo total</span>
                            </div>
                            <div className="text-2xl font-bold">{formatDuration(stats.totalTime)}</div>
                        </div>

                        <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                                <Gauge className="w-4 h-4" />
                                <span>Velocidad promedio</span>
                            </div>
                            <div className="text-2xl font-bold">{formatSpeed(stats.avgSpeed)}</div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Estadísticas de velocidad */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Gauge className="w-5 h-5" />
                        Velocidad
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Velocidad máxima</span>
                            <span className="font-bold text-green-600">{formatSpeed(stats.maxSpeed)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Velocidad promedio</span>
                            <span className="font-bold text-blue-600">{formatSpeed(stats.avgSpeed)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Velocidad mínima</span>
                            <span className="font-bold text-orange-600">{formatSpeed(stats.minSpeed)}</span>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Tiempo en movimiento vs parado */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        Actividad
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                                <span>En movimiento</span>
                                <span className="font-medium">{formatDuration(stats.timeMoving)}</span>
                            </div>
                            <Progress
                                value={stats.totalTime > 0 ? (stats.timeMoving / stats.totalTime) * 100 : 0}
                                className="h-2"
                            />
                        </div>
                        <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                                <span>Detenido</span>
                                <span className="font-medium">{formatDuration(stats.timeStopped)}</span>
                            </div>
                            <Progress
                                value={stats.totalTime > 0 ? (stats.timeStopped / stats.totalTime) * 100 : 0}
                                className="h-2"
                            />
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Información de navegación */}
            {stats.coursesCount > 0 && (
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Navigation className="w-5 h-5" />
                            Navegación
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-2">
                            <div className="flex justify-between items-center">
                                <span className="text-sm text-gray-600">Rumbo promedio</span>
                                <span className="font-bold">{stats.avgCourse.toFixed(0)}°</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-sm text-gray-600">Puntos con rumbo</span>
                                <span className="font-bold">{stats.coursesCount}</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    )
}
