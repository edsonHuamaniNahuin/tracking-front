import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
    Clock,
    MapPin,
    Navigation,
    Anchor,
    Activity,
    TrendingUp,
    TrendingDown,
    Minus
} from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import type { Tracking } from "@/types/tracking"

interface TrackingTimelineProps {
    trackings: Tracking[]
    selectedTracking: Tracking | null
    onTrackingSelect: (tracking: Tracking) => void
    isLoading?: boolean
}

export function TrackingTimeline({
    trackings,
    selectedTracking,
    onTrackingSelect,
    isLoading = false
}: TrackingTimelineProps) {
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')    // Ordenar trackings por fecha
    const sortedTrackings = [...trackings].sort((a, b) => {
        const dateA = new Date(a.reportedAt || a.tracked_at || a.created_at).getTime()
        const dateB = new Date(b.reportedAt || b.tracked_at || b.created_at).getTime()
        return sortOrder === 'desc' ? dateB - dateA : dateA - dateB
    })

    // Función para obtener el estado del movimiento
    const getMovementStatus = (tracking: Tracking, index: number) => {
        if (index === 0 || sortedTrackings.length === 1) return 'initial'

        const prevTracking = sortedTrackings[index - 1]
        const currentSpeed = tracking.speed || 0
        const prevSpeed = prevTracking.speed || 0

        if (currentSpeed > prevSpeed + 2) return 'accelerating'
        if (currentSpeed < prevSpeed - 2) return 'decelerating'
        if (currentSpeed < 1) return 'stopped'
        return 'steady'
    }

    // Función para obtener el icono del estado
    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'accelerating':
                return <TrendingUp className="w-4 h-4 text-green-500" />
            case 'decelerating':
                return <TrendingDown className="w-4 h-4 text-orange-500" />
            case 'stopped':
                return <Anchor className="w-4 h-4 text-red-500" />
            case 'steady':
                return <Minus className="w-4 h-4 text-blue-500" />
            default:
                return <Navigation className="w-4 h-4 text-gray-500" />
        }
    }

    // Función para formatear la velocidad
    const formatSpeed = (speed?: number) => {
        if (!speed) return '0 kn'
        return `${speed.toFixed(1)} kn`
    }

    // Función para formatear la distancia entre puntos
    const calculateDistance = (tracking: Tracking, index: number) => {
        if (index === 0 || sortedTrackings.length === 1) return null

        const prevTracking = sortedTrackings[index - 1]
        if (!prevTracking.latitude || !prevTracking.longitude ||
            !tracking.latitude || !tracking.longitude) return null

        // Fórmula de Haversine para calcular distancia
        const R = 6371 // Radio de la Tierra en km
        const dLat = (tracking.latitude - prevTracking.latitude) * Math.PI / 180
        const dLon = (tracking.longitude - prevTracking.longitude) * Math.PI / 180
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(prevTracking.latitude * Math.PI / 180) *
            Math.cos(tracking.latitude * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2)
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        const distance = R * c

        return distance < 1 ? `${(distance * 1000).toFixed(0)}m` : `${distance.toFixed(2)}km`
    }

    if (isLoading) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        Línea de Tiempo
                    </CardTitle>
                    <CardDescription>
                        Cargando historial de seguimiento...
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {[...Array(5)].map((_, i) => (
                            <div key={i} className="flex items-start gap-4 p-3 border rounded-lg animate-pulse">
                                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                                <div className="flex-1 space-y-2">
                                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                                    <div className="h-3 bg-gray-100 rounded w-1/2"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        )
    }

    if (!trackings.length) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Clock className="w-5 h-5" />
                        Línea de Tiempo
                    </CardTitle>
                    <CardDescription>
                        No hay datos de seguimiento disponibles
                    </CardDescription>
                </CardHeader>
                <CardContent className="text-center py-8">
                    <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">
                        Selecciona una embarcación y un rango de fechas para ver el historial
                    </p>
                </CardContent>
            </Card>
        )
    }

    return (
        <Card>
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2">
                            <Clock className="w-5 h-5" />
                            Línea de Tiempo
                        </CardTitle>
                        <CardDescription>
                            {trackings.length} puntos de seguimiento
                        </CardDescription>
                    </div>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
                    >
                        {sortOrder === 'desc' ? 'Más reciente' : 'Más antiguo'}
                    </Button>
                </div>
            </CardHeader>
            <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-2">
                        {sortedTrackings.map((tracking, index) => {
                            const isSelected = selectedTracking?.id === tracking.id
                            const movementStatus = getMovementStatus(tracking, index)
                            const distance = calculateDistance(tracking, index)
                            const reportDate = new Date(tracking.reportedAt || tracking.tracked_at || tracking.created_at)

                            return (
                                <div
                                    key={tracking.id}
                                    className={`
                                        relative flex items-start gap-4 p-3 border rounded-lg cursor-pointer transition-all
                                        ${isSelected
                                            ? 'border-blue-500 bg-blue-50 shadow-md'
                                            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                                        }
                                    `}
                                    onClick={() => onTrackingSelect(tracking)}
                                >
                                    {/* Línea conectora */}
                                    {index < sortedTrackings.length - 1 && (
                                        <div className="absolute left-7 top-12 w-0.5 h-8 bg-gray-200"></div>
                                    )}

                                    {/* Icono de estado */}
                                    <div className={`
                                        flex items-center justify-center w-8 h-8 rounded-full border-2 bg-white z-10
                                        ${isSelected ? 'border-blue-500' : 'border-gray-300'}
                                    `}>
                                        {getStatusIcon(movementStatus)}
                                    </div>

                                    {/* Contenido */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between mb-1">
                                            <div className="flex items-center gap-2">
                                                <span className="font-medium text-sm">
                                                    {format(reportDate, 'HH:mm:ss', { locale: es })}
                                                </span>
                                                <Badge variant="outline" className="text-xs">
                                                    {formatSpeed(tracking.speed)}
                                                </Badge>
                                            </div>
                                            {distance && (
                                                <Badge variant="secondary" className="text-xs">
                                                    +{distance}
                                                </Badge>
                                            )}
                                        </div>

                                        <div className="flex items-center gap-1 text-xs text-gray-600 mb-1">
                                            <MapPin className="w-3 h-3" />
                                            <span className="truncate">
                                                {tracking.latitude?.toFixed(6)}, {tracking.longitude?.toFixed(6)}
                                            </span>
                                        </div>

                                        <div className="text-xs text-gray-500">
                                            {format(reportDate, 'dd MMM yyyy', { locale: es })}
                                        </div>

                                        {tracking.course && (
                                            <div className="flex items-center gap-1 text-xs text-gray-600 mt-1">
                                                <Navigation className="w-3 h-3" />
                                                <span>{tracking.course}°</span>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </ScrollArea>
            </CardContent>
        </Card>
    )
}
