"use client"

import { useEffect, useState, useRef } from "react"
import type { Tracking } from "@/types/tracking"
import type { Vessel } from "@/types/models/vessel"

interface TrackingMapProps {
    trackings: Tracking[]
    selectedTracking: Tracking | null
    showTrajectory: boolean
    showAllVessels: boolean
    allVessels: Vessel[]
    onTrackingClick: (tracking: Tracking) => void
    height?: number
    isLoading?: boolean
}

export function TrackingMap({
    trackings,
    selectedTracking,
    showTrajectory,
    showAllVessels,
    allVessels,
    onTrackingClick,
    height = 600,
    isLoading = false
}: TrackingMapProps) {
    const [isClient, setIsClient] = useState(false)
    const [mapStatus, setMapStatus] = useState("Inicializando mapa de tracking...")
    const mapRef = useRef<HTMLDivElement>(null)
    const mapInstanceRef = useRef<L.Map | null>(null)
    const markersRef = useRef<L.Marker[]>([])
    const trajectoryRef = useRef<L.Polyline | null>(null)

    useEffect(() => {
        setIsClient(true)
    }, [])

    useEffect(() => {
        if (!isClient || !mapRef.current) return
        initMap()
    }, [isClient])

    useEffect(() => {
        if (mapInstanceRef.current) {
            updateMapData()
        }
    }, [trackings, showTrajectory, showAllVessels, selectedTracking])

    const initMap = async () => {
        try {
            setMapStatus("Cargando Leaflet...")
            const L = (await import("leaflet")).default

            // Limpiar mapa anterior
            if (mapInstanceRef.current) {
                mapInstanceRef.current.remove()
                mapInstanceRef.current = null
            }

            // Configurar iconos
            delete (L.Icon.Default.prototype as any)._getIconUrl
            L.Icon.Default.mergeOptions({
                iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
                iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
                shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
            })

            setMapStatus("Creando mapa...")

            // Crear mapa
            const map = L.map(mapRef.current!, {
                zoomControl: true,
                scrollWheelZoom: true,
                doubleClickZoom: true,
                dragging: true,
                attributionControl: true
            }).setView([20, 0], 3)

            // Agregar tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18,
                keepBuffer: 4
            }).addTo(map)

            mapInstanceRef.current = map
            setMapStatus("✅ Mapa listo")

            // Forzar redimensionado
            setTimeout(() => {
                if (mapInstanceRef.current) {
                    mapInstanceRef.current.invalidateSize(true)
                }
            }, 100)

        } catch (error) {
            console.error('Error inicializando mapa:', error)
            setMapStatus(`❌ Error: ${error instanceof Error ? error.message : 'Error desconocido'}`)
        }
    }

    const createTrackingIcon = (tracking: Tracking, isSelected: boolean = false) => {
        const L = window.L || require("leaflet")

        return L.divIcon({
            html: `
                <div style="
                    position: relative;
                    width: ${isSelected ? '20px' : '14px'};
                    height: ${isSelected ? '20px' : '14px'};
                    background-color: ${isSelected ? '#ef4444' : '#3b82f6'};
                    border: ${isSelected ? '3px' : '2px'} solid white;
                    border-radius: 50%;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                    cursor: pointer;
                    transition: all 0.2s ease;
                ">
                    ${isSelected ? '<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 6px; height: 6px; background: white; border-radius: 50%;"></div>' : ''}
                </div>
            `,
            className: 'tracking-point',
            iconSize: [isSelected ? 20 : 14, isSelected ? 20 : 14],
            iconAnchor: [isSelected ? 10 : 7, isSelected ? 10 : 7],
            popupAnchor: [0, isSelected ? -10 : -7]
        })
    }

    const createVesselIcon = (vessel: Vessel) => {
        const L = window.L || require("leaflet")

        return L.divIcon({
            html: `
                <div style="
                    position: relative;
                    width: 24px;
                    height: 24px;
                    background-color: #10b981;
                    border: 2px solid white;
                    border-radius: 50%;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.25);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                ">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
                        <path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2c1.3 0 1.9-.5 2.5-1"/>
                        <path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76"/>
                        <path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6"/>
                        <path d="M12 10v4"/>
                        <path d="M12 2v3"/>
                    </svg>
                </div>
            `,
            className: 'vessel-current-position',
            iconSize: [24, 24],
            iconAnchor: [12, 12],
            popupAnchor: [0, -12]
        })
    }

    const updateMapData = async () => {
        if (!mapInstanceRef.current) return

        const L = window.L || (await import("leaflet")).default
        const map = mapInstanceRef.current

        // Limpiar marcadores anteriores
        markersRef.current.forEach(marker => map.removeLayer(marker))
        markersRef.current = []

        // Limpiar trayectoria anterior
        if (trajectoryRef.current) {
            map.removeLayer(trajectoryRef.current)
            trajectoryRef.current = null
        }

        setMapStatus(`Mostrando ${trackings.length} puntos de tracking...`)

        // Agregar puntos de tracking
        trackings.forEach((tracking, index) => {
            const lat = Number(tracking.latitude)
            const lng = Number(tracking.longitude)

            if (!isNaN(lat) && !isNaN(lng)) {
                const isSelected = selectedTracking?.id === tracking.id
                const marker = L.marker([lat, lng], {
                    icon: createTrackingIcon(tracking, isSelected)
                })

                marker.bindPopup(`
                    <div style="min-width: 200px;">
                        <h4 style="margin: 0 0 8px 0; font-weight: bold;">Punto de Tracking #${tracking.id}</h4>
                        <p style="margin: 2px 0;"><strong>Fecha:</strong> ${new Date(tracking.tracked_at).toLocaleDateString('es-ES')}</p>
                        <p style="margin: 2px 0;"><strong>Hora:</strong> ${new Date(tracking.tracked_at).toLocaleTimeString('es-ES')}</p>
                        <p style="margin: 2px 0;"><strong>Coordenadas:</strong> ${lat.toFixed(6)}, ${lng.toFixed(6)}</p>
                        <p style="margin: 2px 0;"><strong>Secuencia:</strong> ${index + 1} de ${trackings.length}</p>
                    </div>
                `)

                marker.on('click', () => {
                    onTrackingClick(tracking)
                })

                marker.addTo(map)
                markersRef.current.push(marker)
            }
        })

        // Dibujar trayectoria si está habilitada
        if (showTrajectory && trackings.length > 1) {
            const points = trackings
                .map(t => [Number(t.latitude), Number(t.longitude)] as [number, number])
                .filter(([lat, lng]) => !isNaN(lat) && !isNaN(lng))

            if (points.length > 1) {
                trajectoryRef.current = L.polyline(points, {
                    color: '#3b82f6',
                    weight: 3,
                    opacity: 0.7,
                    dashArray: '5, 10'
                }).addTo(map)

                trajectoryRef.current.bindPopup(`
                    <div>
                        <h4 style="margin: 0 0 8px 0; font-weight: bold;">Trayectoria</h4>
                        <p style="margin: 2px 0;"><strong>Total puntos:</strong> ${trackings.length}</p>
                        <p style="margin: 2px 0;"><strong>Desde:</strong> ${new Date(trackings[0].tracked_at).toLocaleDateString('es-ES')}</p>
                        <p style="margin: 2px 0;"><strong>Hasta:</strong> ${new Date(trackings[trackings.length - 1].tracked_at).toLocaleDateString('es-ES')}</p>
                    </div>
                `)
            }
        }

        // Mostrar todas las embarcaciones si está habilitado
        if (showAllVessels) {
            allVessels.forEach(vessel => {
                // Solo mostrar si no es la embarcación actualmente seleccionada
                if (!trackings.some(t => t.vessel_id === vessel.id)) {
                    // Usar coordenadas simuladas o últimas conocidas
                    const lat = Math.random() * 180 - 90
                    const lng = Math.random() * 360 - 180

                    const marker = L.marker([lat, lng], {
                        icon: createVesselIcon(vessel)
                    })

                    marker.bindPopup(`
                        <div>
                            <h4 style="margin: 0 0 8px 0; font-weight: bold;">${vessel.name}</h4>
                            <p style="margin: 2px 0;"><strong>IMO:</strong> ${vessel.imo}</p>
                            <p style="margin: 2px 0;"><strong>Estado:</strong> Sin datos de tracking</p>
                        </div>
                    `)

                    marker.addTo(map)
                    markersRef.current.push(marker)
                }
            })
        }

        // Ajustar vista del mapa
        if (markersRef.current.length > 0) {
            const group = L.featureGroup(markersRef.current)
            map.fitBounds(group.getBounds(), { padding: [20, 20] })
        }

        setMapStatus(`✅ ${trackings.length} puntos mostrados${showTrajectory ? ' con trayectoria' : ''}`)
    }

    if (!isClient) {
        return (
            <div style={{ height }} className="bg-gray-100 rounded flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
            </div>
        )
    }

    return (
        <div style={{ height }} className="relative rounded-lg overflow-hidden">
            <div
                ref={mapRef}
                className="w-full h-full"
                style={{ minHeight: height }}
            />

            {/* Estado */}
            <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm px-3 py-2 rounded-lg shadow-lg border z-[1000]">
                <div className="text-xs font-medium text-gray-700">
                    {isLoading ? "🔄 Cargando datos..." : mapStatus}
                </div>
            </div>

            {/* Leyenda */}
            <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm p-3 rounded-lg shadow-lg border z-[1000]">
                <div className="text-sm font-medium mb-2">Leyenda</div>
                <div className="space-y-2">
                    <div className="flex items-center text-xs">
                        <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-white mr-2"></div>
                        <span>Punto de tracking</span>
                    </div>
                    <div className="flex items-center text-xs">
                        <div className="w-5 h-5 bg-red-500 rounded-full border-2 border-white mr-2"></div>
                        <span>Punto seleccionado</span>
                    </div>
                    {showTrajectory && (
                        <div className="flex items-center text-xs">
                            <div className="w-6 h-0.5 bg-blue-500 mr-2" style={{ borderStyle: 'dashed' }}></div>
                            <span>Trayectoria</span>
                        </div>
                    )}
                    {showAllVessels && (
                        <div className="flex items-center text-xs">
                            <div className="w-4 h-4 bg-green-500 rounded-full border-2 border-white mr-2"></div>
                            <span>Otras embarcaciones</span>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
