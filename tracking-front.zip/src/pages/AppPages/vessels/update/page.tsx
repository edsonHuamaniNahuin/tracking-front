// src/pages/vessels/VesselUpdatePage.tsx
import React, { useState, useEffect } from "react"
import { useNavigate, useParams } from "react-router-dom"
import { vesselService } from "@/services/vessel.service"
import { vesselTypeService } from "@/services/vesselType.service"
import { vesselStatusService } from "@/services/vesselStatus.service"
import type { VesselStatus } from "@/types/models/vesselStatus"
import type { VesselType } from "@/types/models/vesselType"

import type { VesselUpdateRequest } from "@/types/requests/vesselUpdateRequest"
import {
    Card, CardHeader, CardTitle, CardDescription, CardContent,
} from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
    Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Ship, Upload, Loader2 } from "lucide-react"
import { NotificationToast } from "@/components/vessels/notification-toast"

export default function VesselUpdatePage() {
    const { id } = useParams<{ id: string }>()
    const vesselId = Number(id)
    const navigate = useNavigate()

    const [isLoading, setIsLoading] = useState(true)
    const [isSubmitting, setIsSubmitting] = useState(false)
    const [notification, setNotification] = useState<{ message: string; type: "success" | "error" } | null>(null)
    const [vesselTypes, setVesselTypes] = useState<VesselType[]>([])
    const [vesselStatuses, setVesselStatuses] = useState<VesselStatus[]>([])
    const [form, setForm] = useState({
        name: "",
        imo: "",
        vesselTypeId: "",
        vesselStatusId: "",
        description: "",
        photoUrl: "",
    })
    const [errors, setErrors] = useState({
        name: "",
        imo: "",
        vesselTypeId: "",
        vesselStatusId: "",
    })
    const [preview, setPreview] = useState<string | null>(null)

    useEffect(() => {
        (async () => {
            try {
                const [typesRes, statusesRes, vesselRes] = await Promise.all([
                    vesselTypeService.getTypes({ page: 1, per_page: 100 }),
                    vesselStatusService.getStatuses({ page: 1, per_page: 100 }),
                    vesselService.getVessel(vesselId),
                ])
                setVesselTypes(typesRes.data)
                setVesselStatuses(statusesRes.data)
                const v = vesselRes.data
                // Validar vessel_type y vessel_status
                const vesselTypeId = v.vessel_type && v.vessel_type.id ? v.vessel_type.id.toString() : (typesRes.data[0]?.id?.toString() || "")
                const vesselStatusId = v.vessel_status && v.vessel_status.id ? v.vessel_status.id.toString() : (statusesRes.data[0]?.id?.toString() || "")
                setForm({
                    name: v.name,
                    imo: v.imo || "",
                    vesselTypeId,
                    vesselStatusId,
                    description: (v as any).description || "",
                    photoUrl: (v as any).photoUrl || "",
                })
                setPreview((v as any).photoUrl || null)
            } catch (e) {
                setNotification({ message: "Error al cargar datos", type: "error" })
            } finally {
                setIsLoading(false)
            }
        })()
    }, [vesselId])

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target
        setForm((f) => ({ ...f, [name]: value }))
        setErrors((err) => ({ ...err, [name]: "" }))
    }

    const handleSelect = (field: string, value: string) => {
        setForm((f) => ({ ...f, [field]: value }))
        setErrors((err) => ({ ...err, [field]: "" }))
    }

    const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0]
        if (!file) return
        const url = URL.createObjectURL(file)
        setPreview(url)
        setForm((f) => ({ ...f, photoUrl: url }))
    }

    const validate = () => {
        const errs = { name: "", imo: "", vesselTypeId: "", vesselStatusId: "" }
        let ok = true
        if (!form.name.trim()) { errs.name = "Requerido"; ok = false }
        if (!/^IMO\d+$/.test(form.imo)) { errs.imo = "Formato: IMO123"; ok = false }
        if (!form.vesselTypeId) { errs.vesselTypeId = "Requerido"; ok = false }
        if (!form.vesselStatusId) { errs.vesselStatusId = "Requerido"; ok = false }
        setErrors(errs)
        return ok
    }

    const onSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        if (!validate()) return
        setIsSubmitting(true)
        try {
            const payload: VesselUpdateRequest = {
                name: form.name,
                imo: form.imo,
                vessel_type_id: Number(form.vesselTypeId),
                vessel_status_id: Number(form.vesselStatusId),
                description: form.description,
                photoUrl: form.photoUrl,
            }
            await vesselService.updateVessel(vesselId, payload)
            setNotification({ message: "Actualizado OK", type: "success" })
            setTimeout(() => navigate(`/vessels/${vesselId}`), 1200)
        } catch {
            setNotification({ message: "Error al guardar", type: "error" })
        } finally {
            setIsSubmitting(false)
        }
    }

    if (isLoading) {
        return (
            <div className="container mx-auto py-6 text-center">
                <Loader2 className="animate-spin h-6 w-6" />
            </div>
        )
    }

    return (
        <div className="container mx-auto py-6 space-y-6">
            <div className="flex items-center">
                <Button variant="ghost" size="icon" onClick={() => navigate(`/vessels/${vesselId}`)}>
                    <ArrowLeft className="h-5 w-5" />
                </Button>
                <h1 className="text-3xl font-bold ml-2 flex items-center">
                    <Ship className="mr-2" /> Editar Embarcación
                </h1>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Datos de la embarcación</CardTitle>
                    <CardDescription>Modifica y guarda los cambios</CardDescription>
                </CardHeader>
                <CardContent>
                    <form onSubmit={onSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Nombre */}
                            <div className="space-y-2">
                                <Label htmlFor="name">Nombre</Label>
                                <Input
                                    id="name"
                                    name="name"
                                    value={form.name}
                                    onChange={handleChange}
                                    className={errors.name ? "border-destructive" : ""}
                                />
                                {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
                            </div>

                            {/* IMO */}
                            <div className="space-y-2">
                                <Label htmlFor="imo">IMO</Label>
                                <Input
                                    id="imo"
                                    name="imo"
                                    value={form.imo}
                                    onChange={handleChange}
                                    placeholder="IMO123456"
                                    className={errors.imo ? "border-destructive" : ""}
                                />
                                {errors.imo && <p className="text-sm text-destructive">{errors.imo}</p>}
                            </div>

                            {/* Vessel Type */}
                            <div className="space-y-2">
                                <Label htmlFor="vesselType">Tipo</Label>
                                <Select
                                    value={form.vesselTypeId}
                                    onValueChange={(v) => handleSelect("vesselTypeId", v)}
                                >
                                    <SelectTrigger id="vesselType">
                                        <SelectValue placeholder="Selecciona un tipo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {vesselTypes.map((t) => (
                                            <SelectItem key={t.id} value={t.id.toString()}>
                                                {t.name}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                {errors.vesselTypeId && <p className="text-sm text-destructive">{errors.vesselTypeId}</p>}
                            </div>

                            {/* Vessel Status */}
                            <div className="space-y-2">
                                <Label htmlFor="vesselStatus">Estado</Label>
                                <Select
                                    value={form.vesselStatusId}
                                    onValueChange={(v) => handleSelect("vesselStatusId", v)}
                                >
                                    <SelectTrigger id="vesselStatus">
                                        <SelectValue placeholder="Selecciona un estado" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {vesselStatuses.map((s) => (
                                            <SelectItem key={s.id} value={s.id.toString()}>
                                                {s.name}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                {errors.vesselStatusId && <p className="text-sm text-destructive">{errors.vesselStatusId}</p>}
                            </div>
                        </div>

                        {/* Descripción */}
                        <div className="space-y-2">
                            <Label htmlFor="description">Descripción</Label>
                            <Textarea
                                id="description"
                                name="description"
                                value={form.description}
                                onChange={handleChange}
                                rows={4}
                            />
                        </div>

                        {/* Foto */}
                        <div className="space-y-2">
                            <Label htmlFor="photo">Fotografía</Label>
                            <div className="border-2 border-dashed rounded-lg p-4 h-40 flex items-center justify-center relative">
                                {preview ? (
                                    <img src={preview} alt="preview" className="h-full object-contain" />
                                ) : (
                                    <Upload className="h-8 w-8 text-muted-foreground" />
                                )}
                                <input
                                    id="photo"
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImage}
                                    className="absolute inset-0 opacity-0 cursor-pointer"
                                    style={{ zIndex: 10 }}
                                    tabIndex={-1}
                                />
                            </div>
                        </div>

                        {/* Botones */}
                        <div className="flex justify-end space-x-2 pt-4">
                            <Button variant="outline" onClick={() => navigate(`/vessels/${vesselId}`)}>
                                Cancelar
                            </Button>
                            <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting && <Loader2 className="animate-spin mr-2 h-4 w-4" />}
                                Guardar
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>

            {notification && (
                <NotificationToast
                    message={notification.message}
                    type={notification.type}
                    onClose={() => setNotification(null)}
                />
            )}
        </div>
    )
}
