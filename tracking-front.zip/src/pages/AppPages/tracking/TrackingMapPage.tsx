import { useState, useEffect, useCallback } from "react"
import { useSearchParams } from "react-router-dom"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Label } from "@/components/ui/label"
import { TrackingMap } from "@/components/tracking/tracking-map"
import { TrackingTimeline } from "@/components/tracking/tracking-timeline"
import { TrackingStats } from "@/components/tracking/tracking-stats"
import {
    CalendarIcon,
    Ship,
    MapPin,
    Route,
    Download,
    Filter,
    RefreshCw
} from "lucide-react"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { trackingService } from "@/services/tracking.service"
import { vesselService } from "@/services/vessel.service"
import type { Tracking } from "@/types/tracking"
import type { Vessel } from "@/types/models/vessel"

export default function TrackingMapPage() {
    const [searchParams, setSearchParams] = useSearchParams()

    // Estados principales
    const [trackings, setTrackings] = useState<Tracking[]>([])
    const [vessels, setVessels] = useState<Vessel[]>([])
    const [selectedVessel, setSelectedVessel] = useState<number | null>(null)
    const [selectedTracking, setSelectedTracking] = useState<Tracking | null>(null)
    const [isLoading, setIsLoading] = useState(false)
    const [error, setError] = useState<string | null>(null)

    // Estados de filtros
    const [dateFrom, setDateFrom] = useState<Date>(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)) // 7 días atrás
    const [dateTo, setDateTo] = useState<Date>(new Date())
    const [showTrajectory, setShowTrajectory] = useState(true)
    const [showAllVessels, setShowAllVessels] = useState(false)

    // Funciones
    const loadVessels = async () => {
        try {
            const vesselsData = await vesselService.getVessels({ page: 1, per_page: 100 })
            setVessels(vesselsData.data)
        } catch (err) {
            console.error('Error cargando embarcaciones:', err)
            setError('Error al cargar las embarcaciones')
        }
    }

    const loadTrackings = useCallback(async () => {
        if (!selectedVessel) return

        setIsLoading(true)
        setError(null)

        try {
            const from = format(dateFrom, 'yyyy-MM-dd')
            const to = format(dateTo, 'yyyy-MM-dd')

            const trackingsData = await trackingService.getTrackings(selectedVessel, from, to)
            setTrackings(trackingsData)

            // Actualizar URL
            setSearchParams({ vessel: selectedVessel.toString() })

        } catch (err) {
            console.error('Error cargando trackings:', err)
            setError('Error al cargar los datos de tracking')
        } finally {
            setIsLoading(false)
        }
    }, [selectedVessel, dateFrom, dateTo, setSearchParams])

    const handleTrackingClick = (tracking: Tracking) => {
        setSelectedTracking(tracking)
    }

    // Efectos
    useEffect(() => {
        loadVessels()

        // Verificar si hay parámetros de URL
        const vesselIdParam = searchParams.get('vessel')
        if (vesselIdParam) {
            setSelectedVessel(parseInt(vesselIdParam))
        }
    }, [searchParams])

    // Cargar trackings cuando cambie la embarcación seleccionada o las fechas
    useEffect(() => {
        if (selectedVessel) {
            loadTrackings()
        }
    }, [selectedVessel, dateFrom, dateTo, loadTrackings])

    const selectedVesselData = vessels.find(v => v.id === selectedVessel)

    return (
        <div className="container mx-auto py-6 space-y-6 px-6">
            {/* Header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight flex items-center">
                        <Route className="mr-2 h-6 w-6" />
                        Mapa de Tracking
                    </h1>
                    <p className="text-muted-foreground">
                        Visualización interactiva de rutas y trayectorias de embarcaciones
                    </p>
                </div>

                <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Exportar
                    </Button>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={loadTrackings}
                        disabled={!selectedVessel || isLoading}
                    >
                        <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                        Actualizar
                    </Button>
                </div>
            </div>

            {/* Filtros */}
            <Card>
                <CardHeader className="pb-4">
                    <CardTitle className="text-lg flex items-center">
                        <Filter className="mr-2 h-4 w-4" />
                        Filtros de Búsqueda
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {/* Selección de embarcación */}
                        <div className="space-y-2">
                            <Label>Embarcación</Label>
                            <Select
                                value={selectedVessel?.toString() || ""}
                                onValueChange={(value) => setSelectedVessel(parseInt(value))}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Seleccionar embarcación" />
                                </SelectTrigger>
                                <SelectContent>
                                    {vessels.map((vessel) => (
                                        <SelectItem key={vessel.id} value={vessel.id.toString()}>
                                            <div className="flex items-center space-x-2">
                                                <Ship className="h-4 w-4" />
                                                <span>{vessel.name}</span>
                                                <Badge variant="outline" className="text-xs">
                                                    {vessel.vessel_type?.name || 'Sin tipo'}
                                                </Badge>
                                            </div>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        {/* Fecha desde */}
                        <div className="space-y-2">
                            <Label>Fecha desde</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="outline" className="w-full justify-start text-left">
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {format(dateFrom, "dd MMM yyyy", { locale: es })}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        mode="single"
                                        selected={dateFrom}
                                        onSelect={(date) => date && setDateFrom(date)}
                                        initialFocus
                                        locale={es}
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>

                        {/* Fecha hasta */}
                        <div className="space-y-2">
                            <Label>Fecha hasta</Label>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="outline" className="w-full justify-start text-left">
                                        <CalendarIcon className="mr-2 h-4 w-4" />
                                        {format(dateTo, "dd MMM yyyy", { locale: es })}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-auto p-0" align="start">
                                    <Calendar
                                        mode="single"
                                        selected={dateTo}
                                        onSelect={(date) => date && setDateTo(date)}
                                        initialFocus
                                        locale={es}
                                    />
                                </PopoverContent>
                            </Popover>
                        </div>

                        {/* Opciones de visualización */}
                        <div className="space-y-2">
                            <Label>Opciones</Label>
                            <div className="space-y-2">
                                <div className="flex items-center space-x-2">
                                    <input
                                        type="checkbox"
                                        id="show-trajectory"
                                        checked={showTrajectory}
                                        onChange={(e) => setShowTrajectory(e.target.checked)}
                                        className="rounded border-gray-300"
                                    />
                                    <Label htmlFor="show-trajectory" className="text-sm">
                                        Mostrar trayectoria
                                    </Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <input
                                        type="checkbox"
                                        id="show-all-vessels"
                                        checked={showAllVessels}
                                        onChange={(e) => setShowAllVessels(e.target.checked)}
                                        className="rounded border-gray-300"
                                    />
                                    <Label htmlFor="show-all-vessels" className="text-sm">
                                        Mostrar todas las embarcaciones
                                    </Label>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Error */}
            {error && (
                <Card className="border-red-200 bg-red-50">
                    <CardContent className="p-4">
                        <p className="text-red-800">{error}</p>
                    </CardContent>
                </Card>
            )}

            {/* Información de embarcación seleccionada */}
            {selectedVesselData && (
                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="flex items-center space-x-2">
                            <Ship className="h-5 w-5" />
                            <span>{selectedVesselData.name}</span>
                        </CardTitle>
                        <div className="flex items-center space-x-2">
                            <Badge variant="outline">
                                {selectedVesselData.vessel_type?.name || 'Sin tipo'}
                            </Badge>
                            <Badge variant={selectedVesselData.vessel_status?.name === 'Activa' ? 'default' : 'secondary'}>
                                {selectedVesselData.vessel_status?.name || 'Sin estado'}
                            </Badge>
                        </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                        <div className="text-sm text-gray-600">
                            IMO: {selectedVesselData.imo || 'No disponible'}
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Contenido principal */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Mapa */}
                <div className="lg:col-span-2">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <MapPin className="mr-2 h-4 w-4" />
                                Mapa Interactivo
                            </CardTitle>
                            <CardDescription>
                                {selectedVessel
                                    ? `Tracking de ${selectedVesselData?.name || 'embarcación'} del ${format(dateFrom, "dd/MM/yyyy")} al ${format(dateTo, "dd/MM/yyyy")}`
                                    : 'Selecciona una embarcación para ver su tracking'
                                }
                            </CardDescription>
                        </CardHeader>
                        <CardContent className="p-0">
                            <TrackingMap
                                trackings={trackings}
                                selectedTracking={selectedTracking}
                                showTrajectory={showTrajectory}
                                showAllVessels={showAllVessels}
                                allVessels={vessels}
                                onTrackingClick={handleTrackingClick}
                                height={600}
                                isLoading={isLoading}
                            />
                        </CardContent>
                    </Card>
                </div>

                {/* Panel lateral */}
                <div className="space-y-6">
                    {/* Estadísticas */}
                    {trackings.length > 0 && (
                        <TrackingStats
                            trackings={trackings}
                            vessel={selectedVesselData || null}
                            isLoading={isLoading}
                        />
                    )}

                    {/* Timeline de tracking */}
                    {trackings.length > 0 && (
                        <TrackingTimeline
                            trackings={trackings}
                            selectedTracking={selectedTracking}
                            onTrackingSelect={handleTrackingClick}
                            isLoading={isLoading}
                        />
                    )}
                </div>
            </div>
        </div>
    )
}
