
import { ChartAreaInteractive } from "@/components/blocks/chart-area-interactive"
import { DataTable } from "@/components/blocks/data-table"
import { SectionCards } from "@/layouts/dashboard/section-cards"

import data from "@/utils/data/dashboard.json"

export default function HomePage() {
  return (
    <div className="flex flex-1 flex-col">
      <div className="@container/main flex flex-1 flex-col gap-2">
        <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
          <SectionCards />
          <div className="px-4 lg:px-6">
            <ChartAreaInteractive />
          </div>
          <DataTable data={data} />
        </div>
      </div>
    </div>
  )
}
