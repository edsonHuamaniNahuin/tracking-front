
import api from './api'
import { VesselSearchRequest } from '@/types/requests/vesselSearchRequest'
import { VesselPaginatedResponse } from '@/types/pagination/vesselPaginatedResponse'
import { Vessel } from '@/types/models/vessel'
import { VesselCreateRequest } from '@/types/requests/vesselCreateRequest'
import { VesselCreateResponse } from '@/types/responses/vesselCreateResponse'
import { VesselUpdateResponse } from '@/types/responses/vesselUpdateResponse'
import { VesselUpdateRequest } from '@/types/requests/vesselUpdateRequest'
import { VesselResponse } from '@/types/responses/vesselResponse'

export const vesselService = {
  /**
   * Obtiene la lista paginada de embarcaciones con filtros opcionales.
   * @param params Objeto con { page, per_page, name?, imo? }
   */
  getVessels: async (
    params: VesselSearchRequest
  ): Promise<VesselPaginatedResponse> => {
    const response = await api.get<VesselPaginatedResponse>("/vessels", {
      params
    })
    return response.data
  },

  /**
   * Obtiene una embarcación por su ID.
   * GET /vessels/{id}
   */
  getVessel: async (id: number): Promise<VesselResponse> => {
    const response = await api.get<VesselResponse>(`/vessels/${id}`)
    return response.data
  },

  /**
   * Crea una nueva embarcación.
   * POST /vessels
   */
  createVessel: async (payload: VesselCreateRequest): Promise<Vessel> => {
    const response = await api.post<VesselCreateResponse>("/vessels", payload)
    return response.data.data
  },

  /**
   * Actualiza una embarcación existente.
   * PUT /vessels/{id}
   */
  updateVessel: async (
    id: number,
    payload: VesselUpdateRequest
  ): Promise<Vessel> => {
    const response = await api.put<VesselUpdateResponse>(`/vessels/${id}`, payload)
    return response.data.data
  },

  /**
   * Elimina una embarcación.
   * DELETE /vessels/{id}
   */
  deleteVessel: async (id: number): Promise<void> => {
    await api.delete(`/vessels/${id}`)
  },
}