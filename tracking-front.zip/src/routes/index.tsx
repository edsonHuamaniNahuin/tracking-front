// src/router/index.tsx
import React, { type JSX } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import SignIn from '@/pages/AuthPages/PageSignIn'
import HomePage from '@/pages/HomePage'

const PrivateRoute = ({ children }: { children: JSX.Element }) => {
  const { token } = useAuth()
  return token ? children : <Navigate to="/login" replace />
}

export const AppRouter: React.FC = () => (
  <Routes>
    {/* Ruta pública de login */}
    <Route path="/login" element={<SignIn />} />

    {/* Ruta protegida de dashboard */}
    <Route
      path="/"
      element={
        <PrivateRoute>
          <HomePage />
        </PrivateRoute>
      }
    />

    {/* Cualquier otra ruta va a /login */}
    <Route path="*" element={<Navigate to="/login" replace />} />
  </Routes>
)
