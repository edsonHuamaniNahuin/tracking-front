import { Vessel } from "../models/vessel"

export interface VesselCreateResponse {
    status: number
    message: string
    data: Vessel
}