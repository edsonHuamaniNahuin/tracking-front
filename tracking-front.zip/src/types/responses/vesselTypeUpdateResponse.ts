import { VesselType } from "@/types/models/vesselType"

export interface VesselTypeUpdateResponse {
    status: number
    message: string
    data: VesselType
}