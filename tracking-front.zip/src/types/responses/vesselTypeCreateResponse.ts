import { VesselType } from "@/types/models/vesselType"

export interface VesselTypeCreateResponse {
    status: number
    message: string
    data: VesselType
}