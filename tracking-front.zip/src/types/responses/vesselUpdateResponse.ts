import { Vessel } from "../models/vessel"

export interface VesselUpdateResponse {
    status: number
    message: string
    data: Vessel
}