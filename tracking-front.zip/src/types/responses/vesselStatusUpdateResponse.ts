import { VesselStatus } from "@/types/models/vesselStatus"

export interface VesselStatusUpdateResponse {
    status: number
    message: string
    data: VesselStatus
}