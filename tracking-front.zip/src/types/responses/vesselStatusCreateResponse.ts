import { VesselStatus } from "@/types/models/vesselStatus"

export interface VesselStatusCreateResponse {
    status: number
    message: string
    data: VesselStatus
}