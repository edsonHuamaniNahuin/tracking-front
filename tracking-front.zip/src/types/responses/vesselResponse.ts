import { Vessel } from "@/types/models/vessel"

export interface VesselResponse {
    status: number
    message: string
    data: Vessel
}