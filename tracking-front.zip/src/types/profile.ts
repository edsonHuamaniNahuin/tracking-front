
import type { User } from './user';

/**
 * Respuesta genérica estándar de nuestro backend:
 * {
 *   status: number,
 *   message: string,
 *   data: User
 * }
 */
export interface GenericResponse {
    status: number;
    message: string;
    data: User;
}

/**
 * Payload para actualizar datos personales (PUT /user).
 * Solo incluye los campos permitidos.
 */
export interface UpdateProfileRequest {
    name?: string;
    username?: string;
    email?: string;
    phone?: string;
    bio?: string;
    location?: string;
}

export interface UpdateProfileResponse {
    name?: string;
    username?: string;
    email?: string;
    phone?: string;
    bio?: string;
    location?: string;
}

/**
 * Payload para cambiar contraseña (PUT /user/password).
 */
export interface ChangePasswordRequest {
    current_password: string;
    new_password: string;
    new_password_confirmation: string;
}
