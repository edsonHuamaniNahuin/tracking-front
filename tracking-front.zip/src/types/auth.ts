import type { User } from "./user";

export interface LoginRequest {
  email: string;
  password: string;
}


export interface LoginResponse {
  status: number
  message: string
  data: {
    user: User
    access_token: string
    token_type: 'bearer'
    expires_in: number
  } | null
}

export interface AuthContextResponse {
  user: User | null
  loading: boolean
  error: string | null
  initializing: boolean;
  login: (request: LoginRequest) => Promise<void>
  logout: () => void
}