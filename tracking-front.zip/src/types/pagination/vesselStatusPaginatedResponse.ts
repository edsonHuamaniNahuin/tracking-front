import { VesselStatus } from "@/types/models/vesselStatus"

export interface VesselStatusPaginatedResponse {
    data: VesselStatus[]
    meta: {
        current_page: number
        per_page: number
        total: number
        last_page: number
        from: number
        to: number
    }
}