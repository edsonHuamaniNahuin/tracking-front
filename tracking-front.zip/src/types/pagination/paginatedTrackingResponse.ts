import { Tracking } from '../tracking'

export interface PaginatedTrackingResponse {
    status: number;
    message: string;
    data: {
        data: Tracking[];
        current_page: number;
        per_page: number;
        total: number;
        last_page: number;
        from: number;
        to: number;
    }
}
