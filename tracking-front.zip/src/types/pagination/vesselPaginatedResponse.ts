import { Vessel } from "../models/vessel"

export interface VesselPaginatedResponse {
    data: Vessel[]
    meta: {
        current_page: number
        per_page: number
        total: number
        last_page: number
        from: number
        to: number
    }
}
