import { VesselType } from "@/types/models/vesselType"

export interface VesselTypePaginatedResponse {
    data: VesselType[]
    meta: {
        current_page: number
        per_page: number
        total: number
        last_page: number
        from: number
        to: number
    }
}