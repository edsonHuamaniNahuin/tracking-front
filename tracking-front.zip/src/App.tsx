import React from 'react'
import { Routes, Route, HashRouter } from 'react-router-dom'
import { AuthProvider } from '@/context/AuthContext'
import { UIProvider } from '@/context/UIContext'
import PublicRoute from '@/routes/PublicRoute'
import PrivateRoute from '@/routes/PrivateRoute'

import AppLayout from '@/layouts/AppLayout'
import SignIn from '@/pages/AuthPages/PageSignIn'
import HomePage from './pages/HomePage'
import { GlobalDialogs } from './components/common/GlobalDialogs'
import DashboardPage from './pages/AppPages/DashboardPage'
import UserProfilePage from './pages/AppPages/UserProfilePage'
import VesselsPage from './pages/AppPages/vessels/VesselsPage'
import VesselsChartsPage from './pages/AppPages/vessels/VesselsChartsPage'
import VesselCreatePage from './pages/AppPages/vessels/create/page'
import VesselUpdatePage from './pages/AppPages/vessels/update/page'
import VesselViewPage from './pages/AppPages/vessels/view/page'
import TrackingMapPage from './pages/AppPages/tracking/TrackingMapPage'

export default function App() {

  return (
    <HashRouter>
      <AuthProvider>
        <UIProvider>
          <GlobalDialogs />
          <Routes>
            <Route element={<PublicRoute />}>
              <Route path="/signin" element={<SignIn />} />
            </Route>

            <Route element={<PrivateRoute />}>
              <Route element={<AppLayout />}>
                <Route path="/" element={<HomePage />} />
                <Route path="/dashboard" element={<DashboardPage />} />
                <Route path="/user" element={<UserProfilePage />} />

                <Route path="/vessels/create" element={<VesselCreatePage />} />
                <Route path="/vessels/:id/edit" element={<VesselUpdatePage />} />
                <Route path="/vessels/:id" element={<VesselViewPage />} />
                <Route path="/vessels" element={<VesselsPage />} />
                <Route path="/vessels/charts" element={<VesselsChartsPage />} />

                {/* Tracking Routes */}
                <Route path="/tracking/map" element={<TrackingMapPage />} />
              </Route>

            </Route>
          </Routes>
        </UIProvider>
      </AuthProvider>
    </HashRouter >
  )
}
